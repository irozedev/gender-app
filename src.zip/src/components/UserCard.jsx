import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import './UserCard.css';

const UserCard = ({ user, onLogout }) => {
  return (
    <div className="user-card flex items-center space-x-4 p-2 bg-white rounded shadow">
      <img src={user.avatar} alt="avatar" className="w-10 h-10 rounded-full" />
      <span className="text-lg font-bold">{user.nickname}</span>
      <button onClick={onLogout} className="text-red-500">
        <FontAwesomeIcon icon={faSignOutAlt} />
      </button>
    </div>
  );
};

export default UserCard;
